using CalamityOverHeaven.Items.CraftingMaterials;
using JoJoStands.Items;
using JoJoStands.Items.CraftingMaterials;
using JoJoStands.Tiles;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace CalamityOverHeaven.Items
{
    public class MagiciansRedOverHeaven : StandItemClass
    {
        public override int StandSpeed => 7;
        public override int StandType => 2;
        public override string StandProjectileName => "MagiciansRedOverHeaven";
        public override int StandTier => 5;
        public override Color StandTierDisplayColor => Color.White;

        public override void SetStaticDefaults()
        {
            // DisplayName.SetDefault("Magicians Red Over Heaven");
            // Tooltip.SetDefault("Shoot flaming ankhs at the enemies and right-click to grab an enemy!\nSpecial: Cleansing FLame!\nUsed in Stand Slot");
        }

        public override void SetDefaults()
        {
            Item.damage = 190;
            Item.width = 32;
            Item.height = 32;
            Item.maxStack = 1;
            Item.value = 0;
            Item.noUseGraphic = true;
            Item.rare = ItemRarityID.LightPurple;
        }

        public override bool ManualStandSpawning(Player player)
        {
            Projectile.NewProjectile(player.GetSource_FromThis(), player.position, player.velocity, ModContent.ProjectileType<Projectiles.PlayerStands.MagiciansRedOverHeaven.MagiciansRedOverHeaven>(), 0, 0f, Main.myPlayer);

            return true;
        }

        public override void AddRecipes()
        {
            _ = CreateRecipe()
                .AddIngredient(ModContent.ItemType<MagiciansRedFinal>())
                .AddIngredient(ModContent.ItemType<GreenBaby>())
                .AddIngredient(ModContent.ItemType<DiosJournal>())
                .AddIngredient(ModContent.ItemType < TaintedLifeforce>(), 36)
                .AddTile(ModContent.TileType<RemixTableTile>())
                .Register();
        }
    }
}
