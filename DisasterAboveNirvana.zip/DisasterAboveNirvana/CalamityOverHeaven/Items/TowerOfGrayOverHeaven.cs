using JoJoStands;
using JoJoStands.Buffs.Debuffs;
using JoJoStands.Buffs.EffectBuff;
using JoJoStands.Items;
using JoJoStands.Projectiles;
using JoJoStands.Projectiles.PlayerStands;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.IO;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;
using JoJoStands.Networking;
using JoJoStands.Tiles;
using JoJoStands.Items.CraftingMaterials;
using CalamityOverHeaven.Items.CraftingMaterials;

namespace CalamityOverHeaven.Items
{
    public class TowerOfGrayOverHeaven : StandItemClass
    {
        public override int StandSpeed => 5;
        public override int StandType => 2;
        public override string StandProjectileName => "TowerOfGrayOverHeaven";
        public override int StandTier => 5;
        public override Color StandTierDisplayColor => Color.White;

        public override void SetStaticDefaults()
        {
            // DisplayName.SetDefault("Tower of Gray (Final Tier)");
            /* Tooltip.SetDefault("Pierce your enemies with a sharp stinger and tear right through them with right-click!" +
                "\nSpecial: Remote Control" +
                "\nSecond Special: Pierce every enemy in the area with tongue-tearing stinger!" +
                "\nPassive: Attack ignores 40 enemy defence" +
                "\nUsed in Stand Slot"); */
        }

        public override void SetDefaults()
        {
            Item.damage = 108;
            Item.width = 32;
            Item.height = 32;
            Item.maxStack = 1;
            Item.value = 0;
            Item.noUseGraphic = true;
            Item.rare = ItemRarityID.LightPurple;
        }

        public override bool ManualStandSpawning(Player player)
        {
            Projectile.NewProjectile(player.GetSource_FromThis(), player.position, player.velocity, ModContent.ProjectileType<Projectiles.PlayerStands.TowerOfGrayOverHeaven.TowerOfGrayOverHeavenStand>(), 0, 0f, Main.myPlayer);

            return true;
        }

        public override void AddRecipes()
        {
            _ = CreateRecipe()
                .AddIngredient(ModContent.ItemType<TowerOfGrayFinal>())
                .AddIngredient(ModContent.ItemType<GreenBaby>())
                .AddIngredient(ModContent.ItemType<DiosJournal>())
                .AddIngredient(ModContent.ItemType<TaintedLifeforce>(), 36)
                .AddTile(ModContent.TileType<RemixTableTile>())
                .Register();
        }
    }
}
