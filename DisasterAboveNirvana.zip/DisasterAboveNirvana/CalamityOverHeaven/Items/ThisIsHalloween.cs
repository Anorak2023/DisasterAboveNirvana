﻿using JoJoStands;
using JoJoStands.Buffs.Debuffs;
using JoJoStands.Buffs.EffectBuff;
using JoJoStands.Items;
using JoJoStands.Projectiles;
using JoJoStands.Projectiles.PlayerStands;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.IO;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;
using JoJoStands.Networking;
using JoJoStands.Tiles;
using JoJoStands.Items.CraftingMaterials;

namespace CalamityOverHeaven.Items
{
    public class ThisIsHalloween : StandItemClass
    {
        public override int StandSpeed => 4;
        public override int StandType => 1;
        public override string StandProjectileName => "ThisIsHalloween";
        public override int StandTier => 5;
        public override Color StandTierDisplayColor => Color.Black;

        public override void SetStaticDefaults()
        {
            // DisplayName.SetDefault("This Is Halloween");
            // Tooltip.SetDefaultLeft-click to stab enemies and right-click to throw presents!\nSpecial: Summon Sandy's Special Helpers!\nUsed in Stand Slot");
        }

        public override void SetDefaults()
        {
            Item.damage = 152;
            Item.width = 32;
            Item.height = 32;
            Item.noUseGraphic = true;
            Item.maxStack = 1;
            Item.value = 0;
            Item.rare = ItemRarityID.LightPurple;
        }

        public override bool ManualStandSpawning(Player player)
        {
            Projectile.NewProjectile(player.GetSource_FromThis(), player.position, player.velocity, ModContent.ProjectileType<Projectiles.PlayerStands.ThisIsHalloween.ThisIsHalloweenStandT5>(), 0, 0f, Main.myPlayer);
 
            return true;
        }
        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ModContent.ItemType<SandyClawsFinal>())
                .AddIngredient(ModContent.ItemType<RequiemArrow>())
                .AddIngredient(ModContent.ItemType<DeterminedLifeforce>())
                .AddTile(ModContent.TileType<RemixTableTile>())
                .Register();
        }
    }
}
