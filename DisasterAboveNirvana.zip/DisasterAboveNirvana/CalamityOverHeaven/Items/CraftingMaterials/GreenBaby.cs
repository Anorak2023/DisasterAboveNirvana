using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace CalamityOverHeaven.Items.CraftingMaterials
{
    public class GreenBaby : ModItem
    {
        public override void SetStaticDefaults()
        {
            // DisplayName.SetDefault("GreenBaby");
            // Tooltip.SetDefault("A mysterious green child.");
            Item.ResearchUnlockCount = 5;
        }

        public override void SetDefaults()
        {
            Item.width = 36;
            Item.height = 22;
            Item.maxStack = 1;
            Item.value = Item.buyPrice(platinum: 5);
            Item.rare = ItemRarityID.Purple;
        }
    }
}