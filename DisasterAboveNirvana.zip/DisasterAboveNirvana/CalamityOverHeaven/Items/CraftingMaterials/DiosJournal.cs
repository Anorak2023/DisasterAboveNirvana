using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace CalamityOverHeaven.Items.CraftingMaterials
{
    public class DiosJournal : ModItem
    {
        public override void SetStaticDefaults()
        {
            // DisplayName.SetDefault("Dio's Journal");
            // Tooltip.SetDefault("A diary containing cryptic instructions.");
            Item.ResearchUnlockCount = 5;
        }

        public override void SetDefaults()
        {
            Item.width = 36;
            Item.height = 22;
            Item.maxStack = 9999;
            Item.value = Item.buyPrice(platinum: 1);
            Item.rare = ItemRarityID.Purple;
        }
    }
}