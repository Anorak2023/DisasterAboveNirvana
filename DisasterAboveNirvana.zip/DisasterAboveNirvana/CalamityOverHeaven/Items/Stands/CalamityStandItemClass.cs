using JoJoStands.Items;

namespace CalamityOverHeaven.Items.Stands
{
    public class CalamityStandItemClass : StandItemClass
    {
        public virtual bool CalamityStandItem { get; }
    }
}