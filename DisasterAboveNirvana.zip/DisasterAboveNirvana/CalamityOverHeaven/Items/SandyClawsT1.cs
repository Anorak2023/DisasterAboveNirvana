﻿using JoJoStands;
using JoJoStands.Buffs.Debuffs;
using JoJoStands.Buffs.EffectBuff;
using JoJoStands.Items;
using JoJoStands.Projectiles;
using JoJoStands.Projectiles.PlayerStands;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.IO;
using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;
using JoJoStands.Networking;
using JoJoStands.Items.CraftingMaterials;
using JoJoStands.Tiles;

namespace CalamityOverHeaven.Items
{
    public class SandyClawsT1 : StandItemClass
    {
        public override int StandSpeed => 10;
        public override int StandType => 1;
        public override string StandProjectileName => "SandyClaws";
        public override int StandTier => 1;
        public override Color StandTierDisplayColor => Color.Red;

        public override void SetStaticDefaults()
        {
            // DisplayName.SetDefault("Sandy Claws (Tier 1)");
            /* Tooltip.SetDefault("Left-click to stab enemies!\nUsed in Stand Slot" +
                "\nUsed in Stand Slot"); */
        }

        public override void SetDefaults()
        {
            Item.damage = 12;
            Item.width = 32;
            Item.height = 32;
            Item.noUseGraphic = true;
            Item.maxStack = 1;
            Item.value = 0;
            Item.rare = ItemRarityID.LightPurple;
        }

        public override bool ManualStandSpawning(Player player)
        {
            Projectile.NewProjectile(player.GetSource_FromThis(), player.position, player.velocity, ModContent.ProjectileType<Projectiles.PlayerStands.SandyClaws.SandyClawsStandT1>(), 0, 0f, Main.myPlayer);

            return true;
        }

        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ModContent.ItemType<StandArrow>())
                .AddIngredient(ModContent.ItemType<WillToChange>())
                .AddTile(ModContent.TileType<RemixTableTile>())
                .Register();
        }
    }
}
