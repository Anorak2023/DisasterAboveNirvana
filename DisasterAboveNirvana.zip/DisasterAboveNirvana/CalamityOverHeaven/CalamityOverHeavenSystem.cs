﻿using Microsoft.Xna.Framework;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;
using Terraria.UI;

namespace CalamityOverHeaven
{
    public class CalamityOverHeavenSystem : ModSystem { }
}
