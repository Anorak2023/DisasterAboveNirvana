using System.ComponentModel;
using Terraria.ModLoader.Config;

namespace CalamityOverHeaven
{
    public class CustomizableOptions : ModConfig
    {
        public override ConfigScope Mode => ConfigScope.ClientSide;
    }
}