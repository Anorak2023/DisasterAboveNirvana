using JoJoStands;
using JoJoStands.UI;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using System;
using Terraria;
using Terraria.ModLoader;

namespace CalamityOverHeaven
{
    public class CalamityOverHeaven : Mod
    {
        public static Mod JoJoStandsMod;
        public static Mod CalamityMod;
        public static CalamityOverHeaven Instance;

        public override void Load()
        {
            Instance = ModContent.GetInstance<CalamityOverHeaven>();
            JoJoStandsMod = ModLoader.GetMod("JoJoStands");
            CalamityMod = ModLoader.GetMod("CalamityMod");
        }
    }
}