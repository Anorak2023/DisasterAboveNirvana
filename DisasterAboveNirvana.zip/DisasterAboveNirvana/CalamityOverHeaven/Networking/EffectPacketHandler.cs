using System.IO;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace CalamityOverHeaven.Networking
{
    public class EffectPacketHandler : PacketHandler
    {
        public EffectPacketHandler(byte handlerType) : base(handlerType)
        { }

        public override void HandlePacket(BinaryReader reader, int fromWho)
        {
            throw new System.NotImplementedException();
        }
    }
}