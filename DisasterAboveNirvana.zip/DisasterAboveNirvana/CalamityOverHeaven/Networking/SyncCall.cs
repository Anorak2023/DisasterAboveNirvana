﻿using Terraria;
using Terraria.ID;

namespace CalamityOverHeaven.Networking
{
    public class SyncCall
    {}
}
