using JoJoStands.Buffs.EffectBuff;
using Microsoft.Xna.Framework;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace CalamityOverHeaven.NPCs
{
    public class FanGlobalNPC : GlobalNPC
    {
        public static List<int> nonExistantTypes = new List<int>(5);

        public bool nonExistant = false;
        public int frameCounterDelayTimer = 0;

        public override bool InstancePerEntity
        {
            get { return true; }
        }

        public override bool PreAI(NPC npc)
        {
            FanPlayer fPlayer = Main.LocalPlayer.GetModPlayer<FanPlayer>();
            return true;
        }

        public override void PostAI(NPC npc)
        {
            base.PostAI(npc);
        }

        public override bool CheckActive(NPC npc)
        {
            for (int n = 0; n < nonExistantTypes.Count; n++)
            {
                if (npc.type == nonExistantTypes[n])
                {
                    npc.active = false;
                }
            }
            return true;
        }
    }
}