using JoJoStands;
using JoJoStands.Items.Hamon;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameInput;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace CalamityOverHeaven
{
    public class FanPlayer : ModPlayer
    {}
}