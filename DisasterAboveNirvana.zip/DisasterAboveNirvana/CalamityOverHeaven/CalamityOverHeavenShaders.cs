﻿using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ModLoader;


namespace CalamityOverHeaven
{
    public class CalamityOverHeavenShaders
    {}
}
